module.exports = {
  //local MongoDB deployment ->
  "URI": "mongodb+srv://juj:jujfordinner@cluster0.ijym5.mongodb.net/Cluster0?retryWrites=true&w=majority"
  //"mongodb://localhost/books229"
};
