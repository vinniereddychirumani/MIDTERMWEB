# COMP229-F2019-MidTerm Test

## Welcome to the MidTerm Project - the Favourite Book List App

please use **`npm install`** to install project dependencies
